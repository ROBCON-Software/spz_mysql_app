// library globals;

String serverIp = '192.168.23.200';       // IP adresa MySQL servera
int serverPort = 3306;                   // Port MySQL servera
String databaseName = 'tree';          // Názov databázy
String loginName = 'root';             // Prihlasovacie meno
String loginPassword = 'TAJNEheslo123ABC!@#';    // Heslo
double fontSize = 20;

const String baseApiUrl = "http://195.80.183.109:25001/spz_db/api";
const int pinLength = 4;